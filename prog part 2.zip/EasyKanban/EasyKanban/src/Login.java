import java.util.HashMap;
import java.util.regex.Pattern;

public class Login {
    private final HashMap<String, String[]> users = new HashMap<>(); // Store user data: username -> [password, firstName, lastName]

    // Check if the username is correctly formatted
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check if the password meets complexity requirements
    public boolean checkPasswordComplexity(String password) {
        String passwordPattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=]).{8,}$";
        return Pattern.matches(passwordPattern, password);
    }

    // Register a user
    public String registerUser(String username, String password, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        users.put(username, new String[]{password, firstName, lastName});
        return "Username and password successfully captured.";
    }

    // Log in a user
    public boolean loginUser(String username, String password) {
        return users.containsKey(username) && users.get(username)[0].equals(password);
    }

    // Return login status
    public String returnLoginStatus(String username) {
        if (users.containsKey(username)) {
            String[] userDetails = users.get(username);
            return "Welcome " + userDetails[1] + " " + userDetails[2] + ", it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}
